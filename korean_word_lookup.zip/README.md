# Korean Word Lookup Chrome Extension

## Credits
Dictionary data provided by National Institute of Korean Language's Basic Korean Dictionary (https://krdict.korean.go.kr)

## License
This project is licensed under the Creative Commons Attribution-ShareAlike 2.0 Korea License.
See the [LICENSE](LICENSE) file for details.

---

